# Tests — Librarian Search Strategy Query Builder

Test cases for evaluating output quality. Each test specifies the input prompt,
the assertions that must hold, and the assertions that must NOT hold.

---

## Test Format

Each test has:
- `id` — unique identifier
- `input` — user message
- `must_include` — behaviors/content that must appear in the output
- `must_not_include` — anti-patterns that must be absent
- `notes` — grading guidance

---

## T01 — Epidemiological topic with geographic context (French)

**Input:** `prévalence diabète au Mali`

**Must include:**
- [ ] Topic restated in 1–2 sentences
- [ ] `diabetes` / `diabète` classified as `core`
- [ ] `Mali` classified as `context` and included in the query
- [ ] `prevalence` classified as `refinement` (not `core`)
- [ ] A broad query containing only `diabetes` + `Mali` blocks
- [ ] A focused query that adds a prevalence/epidemiology block
- [ ] MeSH suggestion for `Diabetes Mellitus`
- [ ] MeSH suggestion for `Mali`
- [ ] Notes mentioning supplementary African databases
- [ ] Interface language is French

**Must NOT include:**
- [ ] `prevalence` in the broad query
- [ ] A PICO framework (this is a descriptive, not a clinical question)
- [ ] Invented MeSH terms
- [ ] `ranking` terms used inside any query string

---

## T02 — Methodological / statistical topic

**Input:** `impact of time discretization in causal inference`

**Must include:**
- [ ] Research type identified as methodological or statistical
- [ ] `time discretization` classified as `core`
- [ ] `causal inference` classified as `core`
- [ ] MSM / TMLE / IPW classified as `refinement` (not `core`)
- [ ] `bias` classified as `ranking` only — not included in any query
- [ ] Warning or note that result volume will be low
- [ ] Suggestion to use citation tracking or statistics databases
- [ ] Focused query adds MSM/TMLE terms

**Must NOT include:**
- [ ] PICO framework
- [ ] `bias` inside any query string
- [ ] Overly generic synonyms for `causal inference` (e.g., `causality` alone)
- [ ] MeSH terms for concepts that have no reliable mapping (no invented mappings)

---

## T03 — Clinical intervention question — PICO should be applied

**Input:** `Does CBT reduce insomnia severity in adults with anxiety?`

**Must include:**
- [ ] PICO framework identified as applicable
- [ ] P: adults with anxiety / insomnia
- [ ] I: cognitive behavioural therapy (CBT)
- [ ] O: insomnia severity, sleep outcomes
- [ ] MeSH: `Cognitive Behavioral Therapy` (or `Cognitive Therapy`)
- [ ] MeSH: `Sleep Initiation and Maintenance Disorders`
- [ ] `effectiveness` or `efficacy` classified as `ranking` — not in query
- [ ] Suggestion of RCT publication type filter in focused query

**Must NOT include:**
- [ ] `effectiveness` inside any query string
- [ ] `efficacy` inside any query string
- [ ] No mention of PICO when it clearly applies

---

## T04 — Qualitative topic — no clinical filters

**Input:** `patients' experiences of living with chronic pain`

**Must include:**
- [ ] Research type identified as qualitative / experiential
- [ ] `chronic pain` as `core` with MeSH mapping
- [ ] `patient experience` / `lived experience` as `core`
- [ ] A qualitative study filter block in the focused query (e.g., `qualitative`, `interview*`, `thematic`)
- [ ] Note explaining that clinical study filters (RCT, controlled trial) are inappropriate here

**Must NOT include:**
- [ ] PICO framework
- [ ] RCT or clinical trial filter
- [ ] `outcomes` as a core concept (it is a ranking concept in qualitative research)

---

## T05 — PubMed database adaptation

**Input:** `antibiotic resistance in hospital-acquired infections — PubMed query please`

**Must include:**
- [ ] `[tiab]` field tags on all free-text terms
- [ ] `[MeSH Terms]` or `[MeSH]` on controlled vocabulary terms
- [ ] Concept blocks structured as `(MeSH_term[MeSH] OR free_text[tiab] OR synonym[tiab])`
- [ ] `antibiotic resistance` mapped to `Drug Resistance, Microbial [MeSH]` or similar
- [ ] `hospital-acquired infection` mapped to `Cross Infection [MeSH]` or `Healthcare-Associated Infections [MeSH]`
- [ ] Valid PubMed syntax (no Embase or Scopus operators)

**Must NOT include:**
- [ ] Embase-style operators (`:ab,ti`, `/exp`)
- [ ] Scopus-style operators (`TITLE-ABS-KEY`)
- [ ] WoS-style operators (`TS=`)

---

## T06 — Embase database adaptation

**Input:** `antidepressants and weight gain — Embase`

**Must include:**
- [ ] Emtree terms with `/exp` or `/de` syntax
- [ ] `:ab,ti` field tags for free-text terms
- [ ] `AND [humans]/lim` suggested as optional human filter
- [ ] `antidepressants` mapped to an Emtree term
- [ ] `weight gain` mapped to an Emtree term

**Must NOT include:**
- [ ] PubMed-style `[tiab]` or `[MeSH]` tags
- [ ] Scopus or WoS operators

---

## T07 — Overly broad topic — disambiguation

**Input:** `mental health`

**Must include:**
- [ ] An explicit warning that the topic is too broad
- [ ] A single clarifying question (not multiple questions)
- [ ] A minimal partial query so the user is not left empty-handed

**Must NOT include:**
- [ ] A full strategy treating `mental health` as if it were a workable research question
- [ ] Multiple clarifying questions in one response
- [ ] Refusal to provide any query at all

---

## T08 — Multi-database request

**Input:** `impact of social media on adolescent depression — give me PubMed and Scopus versions`

**Must include:**
- [ ] A PubMed version with `[tiab]` and `[MeSH]` tags
- [ ] A Scopus version with `TITLE-ABS-KEY(...)` syntax
- [ ] `social media` as `core`
- [ ] `adolescents` / `teenagers` as `context` (include in query — it is central to the question)
- [ ] `depression` as `core` with MeSH mapping
- [ ] Sections clearly labelled for each database

**Must NOT include:**
- [ ] Mixed syntax in a single query (PubMed tags inside Scopus query or vice versa)
- [ ] `adolescents` classified as `ranking` (it is central here)

---

## T09 — User asks only for MeSH terms

**Input:** `What are the MeSH terms for post-traumatic stress disorder and eye movement desensitization?`

**Must include:**
- [ ] `Stress Disorders, Post-Traumatic [MeSH]` or equivalent
- [ ] `Eye Movement Desensitization Reprocessing [MeSH]`
- [ ] Brief note about verifying in the MeSH browser
- [ ] Offer to build a full query if needed

**Must NOT include:**
- [ ] A full search strategy (the user only asked for MeSH terms)
- [ ] Invented or unverified MeSH terms

---

## T10 — Language policy: French user, English search terms

**Input (French):** `je cherche des articles sur l'efficacité du jeûne intermittent sur la glycémie`

**Must include:**
- [ ] Interface response in French
- [ ] Search terms in English (e.g., `intermittent fasting`, `blood glucose`, `glycemia`)
- [ ] Note explaining that English terms are used for international databases

**Must NOT include:**
- [ ] French-language search terms in the query (e.g., `jeûne intermittent` in the PubMed query)
- [ ] Interface response in English

---

## Grading Notes

For each test, assess on a 3-point scale per assertion:
- **2** — Assertion fully satisfied
- **1** — Assertion partially satisfied (concept present but imprecise or misclassified)
- **0** — Assertion absent or violated

Threshold for a passing test: ≥ 80% of `must_include` assertions scored ≥ 1,
AND zero `must_not_include` violations.

Critical failures (automatic fail regardless of other scores):
- `ranking` term appears inside any query string
- PICO framework forced on a non-clinical topic
- Invented MeSH/Emtree term presented as verified
- No query provided at all (even for overly broad topics)
- Wrong database syntax in an adaptation request
